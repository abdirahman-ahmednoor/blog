# Profolio project

## Author 
Abdirahman Noor Ahmed 

## Description 
This is wedsite that give my professional skills.

## Setup
To access this project  on you local files, you can clone it using the following step:
1. Open you terminal.
2. use this command to clone, $ git clone https://github.com/abdirahman-ahmednoor/portfolio-project.git
3. This will clone the repository  into your local folder.

## Programmes used
1. HTML
2. CSS
3. Git
 
 ## Live setup
 View [live] https://abdirahman-ahmednoor.github.io/portfolio-project/

 ## License
This project is under the [MIT](License) license .